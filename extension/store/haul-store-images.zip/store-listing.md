# Chrome Web Store listing: Haul - Universal Media Downloader 2.0.0

## Short description (from the manifest, max 132 characters)
Send the video you're watching to Haul on your phone, or save it on this computer.

## Detailed description
Haul sends the video you're watching to your phone, or saves it on your PC.

SEND TO YOUR PHONE
• Scan a QR code and the video opens straight in the Haul Android app.
• Pair once, then send any video with one tap. No scanning needed.

SAVE ON YOUR PC
• Video up to 4K, or audio as MP3, M4A or Opus.
• Save just part of a video: set the start and end times, or tap "Now" while watching.
• Download a whole playlist or channel in one go.
• Subtitles and cover art, if you want them.
• Saving on the PC needs the free Haul PC helper (Windows): https://stackforge-pro.xyz/helper

DOWNLOAD BUTTON ON VIDEOS (optional)
• Point at a video to get a Haul button with Send to phone, Download video and Download audio.
• Hide it on any site with one click.

ALSO
• Right-click menu on pages, links and videos.
• Keyboard shortcuts: Alt+Shift+D (video), Alt+Shift+M (audio), Alt+Shift+Q (send to phone).
• Download history with search, Open, Show in folder and Download again.

Please only download content you have the right to save.

## Category
Tools (or keep your current category)

## Single purpose
Send the video on the current page to the user's phone (Haul app), or download it on the user's computer through the Haul PC helper.

## Permission justifications
- activeTab: Reads the address and title of the current tab when the user opens the popup, uses the right-click menu, or presses a shortcut, so that page can be sent to the phone or downloaded.
- contextMenus: Adds "Send to phone", "Download video", "Download audio" and "Download playlist" to the right-click menu.
- nativeMessaging: Talks to the Haul PC helper the user installs (app.haul.helper). The helper does the actual download on the user's computer with yt-dlp and FFmpeg.
- notifications: Tells the user when a download on the PC has finished or failed.
- scripting: Reads the current time of the video on the page when the user taps "Now" to set clip times, and adds the optional download button to videos after the user turns it on.
- storage: Saves the user's settings, phone pairing and download history on their own browser.
- Host permission (optional, <all_urls>): Only asked when the user turns on the "Download button on videos" setting, so the button can appear on videos on any site. It is off by default.
- Remote code: No. All code is inside the package.

## Data use (Privacy tab)
- Collected: Web history (only the page address and title the user chooses to send to their phone, sent to stackforge-pro.xyz to deliver it to their paired phone). Nothing else.
- Not sold, not used for anything unrelated, not used for credit decisions.
- Privacy policy URL: link your site's privacy page (for example https://stackforge-pro.xyz/privacy).

## Images
- Screenshots (1280×800): 1-video-button, 2-send-to-phone, 3-download-on-pc, 4-settings, 5-history
- Small promo tile (440×280): promo-tile-440x280
